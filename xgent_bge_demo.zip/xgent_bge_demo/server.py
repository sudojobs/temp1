
import json, os, math, threading
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
import io

ROOT = Path(__file__).parent
CONFIG = json.loads((ROOT / "config.json").read_text())

# -------------------- BGE embedding engine --------------------

_EMBEDDER = None
_EMBED_LOCK = threading.Lock()

def _load_bge_model():
    """Lazy-load BGE model (BAAI/bge-base-en-v1.5) via sentence-transformers.

    User must install:
        pip install sentence-transformers torch

    CONFIG['embedding']:
      {
        "model": "BAAI/bge-base-en-v1.5",
        "local_path": "models/bge-base-en-v1.5"
      }
    """
    global _EMBEDDER
    if _EMBEDDER is not None:
        return _EMBEDDER

    with _EMBED_LOCK:
        if _EMBEDDER is not None:
            return _EMBEDDER

        try:
            from sentence_transformers import SentenceTransformer
        except Exception as e:
            raise RuntimeError(
                "sentence-transformers is not installed. "
                "Run 'pip install sentence-transformers torch' to enable BGE embeddings."
            ) from e

        emb_cfg = CONFIG.get("embedding", {})
        model_name = emb_cfg.get("local_path") or emb_cfg.get("model") or "BAAI/bge-base-en-v1.5"
        print(f"[BGE] Loading embedding model from: {model_name}")
        model = SentenceTransformer(model_name)
        _EMBEDDER = model
        return _EMBEDDER


def embed_texts(texts):
    """Return L2-normalised BGE embeddings for a list of strings.

    If sentence-transformers / model is not available, raises a clear RuntimeError.
    """
    if not texts:
        return []

    model = _load_bge_model()
    embs = model.encode(texts, batch_size=CONFIG.get("embedding", {}).get("batch_size", 32), normalize_embeddings=True)
    # ensure list of lists for JSON-friendliness if needed
    return [list(map(float, v)) for v in embs]


def _np():
    import numpy as _np
    return _np


class EmbeddingIndex:
    """Simple dense index backed by .npz (embeddings) + .json (metadata).

    Each add() call appends new rows. search() uses cosine similarity (dot-product)
    assuming embeddings are already L2-normalised.
    """
    def __init__(self, prefix: Path):
        self.prefix = prefix
        self.emb = None   # numpy array [N, D]
        self.meta = []    # list of dicts
        self._loaded = False

    @property
    def npz_path(self):
        return self.prefix.with_suffix(".npz")

    @property
    def meta_path(self):
        return self.prefix.with_suffix(".json")

    def load(self):
        if self._loaded:
            return
        np = _np()
        if self.npz_path.exists():
            data = np.load(self.npz_path)
            self.emb = data["emb"]
        else:
            self.emb = None
        if self.meta_path.exists():
            self.meta = json.loads(self.meta_path.read_text(encoding="utf-8"))
        else:
            self.meta = []
        self._loaded = True

    def save(self):
        np = _np()
        self.prefix.parent.mkdir(parents=True, exist_ok=True)
        if self.emb is None:
            arr = np.zeros((0, 768), dtype="float32")
        else:
            arr = self.emb
        np.savez(self.npz_path, emb=arr)
        self.meta_path.write_text(json.dumps(self.meta, indent=2), encoding="utf-8")

    def _ensure_loaded(self):
        if not self._loaded:
            self.load()

    def add(self, texts, meta_list):
        assert len(texts) == len(meta_list), "texts and meta length mismatch"
        self._ensure_loaded()
        vecs = embed_texts(texts)
        np = _np()
        arr = np.array(vecs, dtype="float32")
        if self.emb is None:
            self.emb = arr
        else:
            self.emb = np.vstack([self.emb, arr])
        self.meta.extend(meta_list)
        self.save()

    def search(self, query_text, top_k=5):
        self._ensure_loaded()
        if self.emb is None or len(self.meta) == 0:
            return []
        q_vec = embed_texts([query_text])[0]
        np = _np()
        q = np.array(q_vec, dtype="float32")
        # cos sim = dot product since all embeddings normalised
        scores = self.emb @ q
        idx = scores.argsort()[::-1][:top_k]
        results = []
        for i in idx:
            m = dict(self.meta[int(i)])
            m["score"] = float(scores[int(i)])
            results.append(m)
        return results


JIRA_INDEX = EmbeddingIndex(ROOT / "indices" / "jira_bge")

# -------------------- Demo Jira issues --------------------

def _demo_dummy_jira_issue(jira_id: str):
    mapping = {
        "AVSREQ-000001": {
            "summary": "Xcelium sim extremely slow on large UVM env with scoreboards enabled",
            "description": "Regression testcase 'uvm_perf_smoke' shows 3x slowdown vs baseline. Suspect coverage and memory profiling."
        },
        "AVSREQ-000002": {
            "summary": "Coverage hole: missing cross between AXI burst length and protection type",
            "description": "Functional coverage report shows 0% hits on cross cp_lenXprot in 'axi_cov_ccf'."
        },
        "AVSREQ-000003": {
            "summary": "Out-of-memory when dumping large waves with assertion coverage enabled",
            "description": "Xcelium run OOMs on 128G box when FSDB + assertion coverage are both enabled."
        },
        "AVSREQ-000004": {
            "summary": "Elaboration failure with hierarchical reference in UVM RAL model",
            "description": "Compile/elab fails with hierarchical path errors inside auto-generated RAL model."
        },
        "AVSREQ-000005": {
            "summary": "Random stability issue in constrained-random sequence",
            "description": "Nightly regression shows 3% intermittent failures in 'pkt_smoke_seq'."
        },
        "AVSREQ-000006": {
            "summary": "Redundant coverage bins across multiple CCF files",
            "description": "Project uses core/fabric/top CCFs and reports indicate heavy redundancy."
        },
        "AVSREQ-000007": {
            "summary": "CDC assertions firing only under -newperf",
            "description": "CDC-related assertion failures are seen only when -newperf is enabled."
        },
    }
    key = (jira_id or "").strip().upper()
    if key in mapping:
        return {"key": key, **mapping[key]}
    return None


def fetch_jira_issue(jira_id: str):
    demo = _demo_dummy_jira_issue(jira_id)
    if demo:
        return demo
    return {
        "key": jira_id,
        "summary": "Unknown issue",
        "description": "No Jira backend configured; using dummy issue."
    }

def ensure_demo_jira_index():
    """Seed the BGE index with the 7 demo Jira tickets if not present."""
    JIRA_INDEX._ensure_loaded()
    if JIRA_INDEX.emb is not None and len(JIRA_INDEX.meta) >= 7:
        return
    items = []
    texts = []
    for jid in [f"AVSREQ-00000{i}" for i in range(1, 8)]:
        issue = fetch_jira_issue(jid)
        text = f"{issue['key']} {issue['summary']} {issue['description']}"
        texts.append(text)
        items.append({
            "id": issue["key"],
            "summary": issue["summary"],
            "description": issue["description"],
        })
    print("[BGE] Seeding demo Jira index with 7 issues")
    JIRA_INDEX.add(texts, items)

# -------------------- LLM (llama_cpp adapter + stubs) --------------------

def llm_generate(prompt: str):
    adapter = CONFIG.get("llm", {}).get("adapter", "llama_cpp")
    if adapter == "llama_cpp":
        # For demo we do not actually load a GGUF file, but you can replace this stub with:
        #   from llama_cpp import Llama
        #   llm = Llama(model_path=CONFIG["llm"]["model_path"], n_ctx=CONFIG["llm"]["n_ctx"])
        #   out = llm(prompt=prompt, max_tokens=CONFIG["llm"]["max_tokens"], temperature=CONFIG["llm"]["temperature"])
        #   return out["choices"][0]["text"]
        return "[llama_cpp OFFLINE STUB]\n" + prompt[:800]
    elif adapter == "onnx":
        return "[ONNX backend is disabled in this demo]"
    elif adapter == "tensorrt":
        return "[TensorRT backend is disabled in this demo]"
    return "[No LLM configured]"

# -------------------- HTTP handler --------------------

class XgentHandler(SimpleHTTPRequestHandler):
    def _send_json(self, code=200, obj=None):
        data = json.dumps(obj or {}).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path in ("/", "/index.html"):
            self.path = "/ui/index.html"
        return super().doGET()

    # Fix method name typo for SimpleHTTPRequestHandler
    def doGET(self):
        return super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        length = int(self.headers.get("Content-Length","0") or "0")
        raw = self.rfile.read(length) if length > 0 else b"{}"
        try:
            payload = json.loads(raw.decode("utf-8") or "{}")
        except Exception:
            payload = {}

        if parsed.path == "/api/jira_seed_demo":
            try:
                ensure_demo_jira_index()
                return self._send_json(200, {"ok": True, "seeded": True})
            except Exception as e:
                return self._send_json(200, {"ok": False, "error": str(e)})

        if parsed.path == "/api/jira_match":
            text_q = (payload.get("text") or "").strip()
            if not text_q:
                return self._send_json(200, {"ok": False, "error": "empty_query"})
            try:
                ensure_demo_jira_index()
                matches = JIRA_INDEX.search(text_q, top_k=5)
                return self._send_json(200, {"ok": True, "results": matches})
            except Exception as e:
                return self._send_json(200, {"ok": False, "error": str(e)})

        if parsed.path == "/api/jira_flow":
            jira_id = (payload.get("jira_id") or "").strip()
            if not jira_id:
                return self._send_json(200, {"ok": False, "error": "jira_id_required"})
            issue = fetch_jira_issue(jira_id)
            desc = f"{issue['summary']}\n{issue['description']}"
            similar = []
            try:
                ensure_demo_jira_index()
                similar = JIRA_INDEX.search(desc, top_k=5)
            except Exception as e:
                similar = []
            # Fallback: generate testcase/code suggestion via LLM
            gen_prompt = (
                "You are a senior Xcelium/UVM debug engineer. "
                "Given the Jira description below, propose a UVM testcase or debug steps.\n\n"
                f"Jira {issue['key']}: {issue['summary']}\n{issue['description']}"
            )
            gen = llm_generate(gen_prompt)
            resp = {
                "ok": True,
                "issue": issue,
                "similar_jira": similar,
                "generated_testcase": gen,
                "perf_recommendations": [
                    "-newperf",
                    "-plusperf"
                ]
            }
            return self._send_json(200, resp)

        if parsed.path == "/api/llm_chat":
            text_q = (payload.get("text") or "").strip()
            result = llm_generate(text_q)
            return self._send_json(200, {"ok": True, "text": result})

        return self._send_json(404, {"ok": False, "error": "unknown_endpoint"})

def run():
    host = CONFIG["server"]["host"]
    port = CONFIG["server"]["port"]
    httpd = HTTPServer((host, port), XgentHandler)
    print(f"Xgent BGE demo running at http://{host}:{port}")
    httpd.serve_forever()

if __name__ == "__main__":
    run()
