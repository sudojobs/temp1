# Xgent Agentic AI – BGE Edition

This app is a local, offline-first assistant for Xcelium / UVM debug that uses:

- **BGE embeddings** (`BAAI/bge-base-en-v1.5`) for:
  - Jira similarity search
  - PDF/document QA
  - UVM testcase retrieval
- A pluggable **llama_cpp** backend for code generation and reasoning (stubbed by default).
- A single-page web UI with:
  - Login
  - Main Chat (brain routing)
  - PDF Training
  - Jira Training
  - Testcase Training

## 1. Installation

1. Extract this folder, e.g.:

   ```bash
   C:\dev\xgent_agentic_bge_full
   ```

2. Create venv and install Python deps:

   ```bash
   pip install sentence-transformers torch numpy pypdf
   ```

3. (Optional) For real LLM:

   ```bash
   pip install llama-cpp-python
   ```

4. Download BGE model `BAAI/bge-base-en-v1.5` into:

   ```text
   models/bge-base-en-v1.5/
   ```

5. (Optional) Download a GGUF Llama model and place as:

   ```text
   models/llama-demo.gguf
   ```

   Then adjust `config.json` → `llm.model_path`.

## 2. Run

```bash
python server.py
```

Open:

```text
http://localhost:8099/
```

## 3. Login

Default credentials (SQLite):

- user: `xgent`
- pass: `xgent123`

## 4. Tabs

- **Main Chat** – ask Jira IDs, questions, or free text.
- **PDF Training** – upload PDFs for embedding.
- **Jira Training** – train Jira BGE index from CSV.
- **Testcase Training** – train UVM testcase BGE index from CSV.

See README in the chat for detailed behavior.
