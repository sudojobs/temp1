
import json
import os
import math
import threading
import sqlite3
import time
from http.server import HTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse
import io
import re

ROOT = Path(__file__).parent
CONFIG = json.loads((ROOT / "config.json").read_text())

DB_PATH = ROOT / "xgent_ai.sqlite3"

# -------------------- SQLite auth --------------------

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, "
        "username TEXT UNIQUE, password TEXT)"
    )
    conn.commit()
    cur.execute("SELECT id FROM users WHERE username = ?", ("xgent",))
    row = cur.fetchone()
    if not row:
        cur.execute("INSERT INTO users (username, password) VALUES (?,?)", ("xgent", "xgent123"))
        conn.commit()
    conn.close()

def check_login(username, password):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("SELECT id FROM users WHERE username = ? AND password = ?", (username, password))
    row = cur.fetchone()
    conn.close()
    return row is not None

# -------------------- BGE embedding engine --------------------

_EMBEDDER = None
_EMBED_LOCK = threading.Lock()

def _load_bge_model():
    global _EMBEDDER
    if _EMBEDDER is not None:
        return _EMBEDDER
    with _EMBED_LOCK:
        if _EMBEDDER is not None:
            return _EMBEDDER
        try:
            from sentence_transformers import SentenceTransformer
        except Exception as e:
            raise RuntimeError(
                "sentence-transformers is not installed. "
                "Run 'pip install sentence-transformers torch' to enable BGE embeddings."
            ) from e
        emb_cfg = CONFIG.get("embedding", {})
        model_name = emb_cfg.get("local_path") or emb_cfg.get("model") or "BAAI/bge-base-en-v1.5"
        print(f"[BGE] Loading embedding model from: {model_name}")
        model = SentenceTransformer(model_name)
        _EMBEDDER = model
        return _EMBEDDER

def embed_texts(texts):
    if not texts:
        return []
    model = _load_bge_model()
    embs = model.encode(
        texts,
        batch_size=CONFIG.get("embedding", {}).get("batch_size", 16),
        normalize_embeddings=True,
    )
    return [list(map(float, v)) for v in embs]

def _np():
    import numpy as _np
    return _np

class EmbeddingIndex:
    def __init__(self, prefix: Path):
        self.prefix = prefix
        self.emb = None
        self.meta = []
        self._loaded = False

    @property
    def npz_path(self):
        return self.prefix.with_suffix(".npz")

    @property
    def meta_path(self):
        return self.prefix.with_suffix(".json")

    def load(self):
        if self._loaded:
            return
        np = _np()
        if self.npz_path.exists():
            data = np.load(self.npz_path)
            self.emb = data["emb"]
        else:
            self.emb = None
        if self.meta_path.exists():
            self.meta = json.loads(self.meta_path.read_text(encoding="utf-8"))
        else:
            self.meta = []
        self._loaded = True

    def save(self):
        np = _np()
        self.prefix.parent.mkdir(parents=True, exist_ok=True)
        if self.emb is None:
            arr = np.zeros((0, CONFIG.get("embedding_dim", 768)), dtype="float32")
        else:
            arr = self.emb
        np.savez(self.npz_path, emb=arr)
        self.meta_path.write_text(json.dumps(self.meta, indent=2), encoding="utf-8")

    def _ensure_loaded(self):
        if not self._loaded:
            self.load()

    def add(self, texts, meta_list):
        assert len(texts) == len(meta_list), "texts and meta length mismatch"
        self._ensure_loaded()
        vecs = embed_texts(texts)
        np = _np()
        arr = np.array(vecs, dtype="float32")
        if self.emb is None:
            self.emb = arr
        else:
            self.emb = np.vstack([self.emb, arr])
        self.meta.extend(meta_list)
        self.save()

    def search(self, query_text, top_k=5):
        self._ensure_loaded()
        if self.emb is None or len(self.meta) == 0:
            return []
        q_vec = embed_texts([query_text])[0]
        np = _np()
        q = np.array(q_vec, dtype="float32")
        scores = self.emb @ q
        idx = scores.argsort()[::-1][:top_k]
        results = []
        for i in idx:
            m = dict(self.meta[int(i)])
            m["score"] = float(scores[int(i)])
            results.append(m)
        return results

JIRA_INDEX = EmbeddingIndex(ROOT / "indices" / "jira_bge")
TC_INDEX   = EmbeddingIndex(ROOT / "indices" / "testcase_bge")
PDF_INDEX  = EmbeddingIndex(ROOT / "indices" / "pdf_bge")

# -------------------- Demo Jira --------------------

def _demo_dummy_jira_issue(jira_id: str):
    mapping = {
        "AVSREQ-000001": {
            "summary": "Xcelium sim extremely slow on large UVM env with scoreboards enabled",
            "description": "Regression testcase 'uvm_perf_smoke' shows 3x slowdown vs baseline. Suspect coverage and memory profiling."
        },
        "AVSREQ-000002": {
            "summary": "Coverage hole: missing cross between AXI burst length and protection type",
            "description": "Functional coverage report shows 0% hits on cross cp_lenXprot in 'axi_cov_ccf'."
        },
        "AVSREQ-000003": {
            "summary": "Out-of-memory when dumping large waves with assertion coverage enabled",
            "description": "Xcelium run OOMs when FSDB + assertion coverage are both enabled."
        },
        "AVSREQ-000004": {
            "summary": "Elaboration failure with hierarchical reference in UVM RAL model",
            "description": "Compile/elab fails with hierarchical path errors inside auto-generated RAL model."
        },
        "AVSREQ-000005": {
            "summary": "Random stability issue in constrained-random sequence",
            "description": "Nightly regression shows intermittent failures in 'pkt_smoke_seq'."
        },
        "AVSREQ-000006": {
            "summary": "Redundant coverage bins across multiple CCF files",
            "description": "Project uses core/fabric/top CCFs and reports indicate heavy redundancy."
        },
        "AVSREQ-000007": {
            "summary": "CDC assertions firing only under -newperf",
            "description": "CDC-related assertion failures are seen only when -newperf is enabled."
        },
    }
    key = (jira_id or "").strip().upper()
    if key in mapping:
        return {"key": key, **mapping[key]}
    return None

def fetch_jira_issue(jira_id: str):
    demo = _demo_dummy_jira_issue(jira_id)
    if demo:
        return demo
    return {
        "key": jira_id,
        "summary": "Unknown issue",
        "description": "No Jira backend configured; using dummy issue."
    }

def ensure_demo_jira_index():
    JIRA_INDEX._ensure_loaded()
    if JIRA_INDEX.emb is not None and len(JIRA_INDEX.meta) >= 7:
        return
    items = []
    texts = []
    for i in range(1, 8):
        jid = f"AVSREQ-00000{i}"
        issue = fetch_jira_issue(jid)
        text = f"{issue['key']} {issue['summary']} {issue['description']}"
        texts.append(text)
        items.append({
            "id": issue["key"],
            "summary": issue["summary"],
            "description": issue["description"],
        })
    print("[BGE] Seeding demo Jira index with 7 issues")
    JIRA_INDEX.add(texts, items)

# -------------------- PDF helpers --------------------

PDF_META_PATH = ROOT / "pdf_store" / "pdf_meta.json"

def load_pdf_meta():
    if not PDF_META_PATH.exists():
        return {"docs": [], "next_id": 1}
    return json.loads(PDF_META_PATH.read_text(encoding="utf-8"))

def save_pdf_meta(obj):
    PDF_META_PATH.parent.mkdir(parents=True, exist_ok=True)
    PDF_META_PATH.write_text(json.dumps(obj, indent=2), encoding="utf-8")

def _extract_pdf_text(file_bytes: bytes):
    try:
        from pypdf import PdfReader
    except Exception as e:
        raise RuntimeError("pypdf is required for PDF extraction. Install with 'pip install pypdf'") from e
    reader = PdfReader(io.BytesIO(file_bytes))
    pages = []
    for i, p in enumerate(reader.pages):
        try:
            t = p.extract_text() or ""
        except Exception:
            t = ""
        pages.append((i+1, t))
    return pages

def _chunk_text(text, max_chars=800):
    text = text.replace("\r", " ")
    out = []
    buf = []
    length = 0
    for line in text.split("\n"):
        if length + len(line) + 1 > max_chars and buf:
            out.append("\n".join(buf).strip())
            buf = [line]
            length = len(line) + 1
        else:
            buf.append(line)
            length += len(line) + 1
    if buf:
        out.append("\n".join(buf).strip())
    return [p for p in out if p.strip()]

# -------------------- LLM stub (llama_cpp-ready) --------------------

def llm_generate(prompt: str):
    cfg = CONFIG.get("llm", {})
    adapter = cfg.get("adapter", "llama_cpp")
    if adapter == "llama_cpp":
        return "[llama_cpp OFFLINE STUB]\n" + prompt[:1200]
    if adapter == "onnx":
        return "[ONNX backend is disabled in this demo]"
    if adapter == "tensorrt":
        return "[TensorRT backend is disabled in this demo]"
    return "[No LLM configured]"

# -------------------- HTTP helpers --------------------

def parse_json_body(handler):
    length = int(handler.headers.get("Content-Length", "0") or "0")
    raw = handler.rfile.read(length) if length > 0 else b"{}"
    try:
        return json.loads(raw.decode("utf-8") or "{}")
    except Exception:
        return {}

class XgentHandler(SimpleHTTPRequestHandler):
    def _send_json(self, code=200, obj=None):
        data = json.dumps(obj or {}).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path in ("/", "/index.html"):
            self.path = "/ui/index.html"
        return super().do_GET()

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path

        # ---- Auth ----
        if path == "/api/login":
            payload = parse_json_body(self)
            u = (payload.get("username") or "").strip()
            p = payload.get("password") or ""
            if check_login(u, p):
                return self._send_json(200, {"ok": True, "username": u})
            return self._send_json(200, {"ok": False, "error": "invalid_credentials"})

        if path == "/api/logout":
            return self._send_json(200, {"ok": True})

        if path == "/api/config":
            return self._send_json(200, {"ok": True, "config": CONFIG})

        # ---- Jira seeds & match ----
        if path == "/api/jira_seed_demo":
            try:
                ensure_demo_jira_index()
                return self._send_json(200, {"ok": True, "seeded": True})
            except Exception as e:
                return self._send_json(200, {"ok": False, "error": str(e)})

        if path == "/api/jira_match":
            payload = parse_json_body(self)
            text_q = (payload.get("text") or "").strip()
            if not text_q:
                return self._send_json(200, {"ok": False, "error": "empty_query"})
            try:
                ensure_demo_jira_index()
                hits = JIRA_INDEX.search(text_q, top_k=5)
                return self._send_json(200, {"ok": True, "results": hits})
            except Exception as e:
                return self._send_json(200, {"ok": False, "error": str(e)})

        if path == "/api/jira_flow":
            payload = parse_json_body(self)
            jira_id = (payload.get("jira_id") or "").strip()
            desc_override = (payload.get("description_override") or "").strip()
            if not jira_id and not desc_override:
                return self._send_json(200, {"ok": False, "error": "jira_id_or_description_required"})

            issue = fetch_jira_issue(jira_id) if jira_id else None
            base_desc = ""
            if issue:
                base_desc = f"{issue['summary']}\n{issue['description']}"
            if desc_override:
                base_desc = desc_override

            try:
                ensure_demo_jira_index()
                similar = JIRA_INDEX.search(base_desc, top_k=5)
            except Exception:
                similar = []

            try:
                TC_INDEX._ensure_loaded()
                tc_hits = TC_INDEX.search(base_desc, top_k=5) if TC_INDEX.emb is not None else []
            except Exception:
                tc_hits = []

            gen_prompt = (
                "You are a senior Xcelium/UVM debug engineer.\n"
                "Given the Jira description below and similar issues, propose a UVM testcase or debug recipe.\n\n"
                f"Jira: {jira_id or '(text only)'}\n{base_desc}\n\n"
                f"Similar Jira hits: {json.dumps(similar, indent=2)}\n\n"
                f"Suggested testcases: {json.dumps(tc_hits, indent=2)}\n"
            )
            gen = llm_generate(gen_prompt)

            resp = {
                "ok": True,
                "jira_id": jira_id,
                "issue": issue,
                "description": base_desc,
                "similar_jira": similar,
                "testcases": tc_hits,
                "generated_testcase": gen,
                "perf_recommendations": ["-newperf", "-plusperf"],
            }
            return self._send_json(200, resp)

        # ---- Jira training CSV ----
        if path == "/api/jira_upload_train":
            ctype = self.headers.get("Content-Type", "")
            if "multipart/form-data" not in ctype:
                return self._send_json(400, {"ok": False, "error": "multipart_required"})
            length = int(self.headers.get("Content-Length", "0") or "0")
            raw = self.rfile.read(length)
            m = re.search(b"boundary=(.+)", ctype.encode())
            if not m:
                return self._send_json(400, {"ok": False, "error": "no_boundary"})
            boundary = b"--" + m.group(1)
            parts = raw.split(boundary)
            csv_bytes = b""
            for part in parts:
                if b"Content-Disposition" in part and b'name="file"' in part:
                    sep = b"\r\n\r\n"
                    idx = part.find(sep)
                    if idx != -1:
                        csv_bytes = part[idx+len(sep):]
                        csv_bytes = csv_bytes.rstrip(b"\r\n--")
                        break
            if not csv_bytes:
                return self._send_json(400, {"ok": False, "error": "no_file"})
            import csv as _csv
            from io import StringIO
            txt = csv_bytes.decode("utf-8", errors="ignore")
            rows = list(_csv.DictReader(StringIO(txt)))
            if not rows:
                return self._send_json(200, {"ok": False, "error": "empty_csv"})
            texts, meta = [], []
            for r in rows:
                tid = r.get("id", "")
                summary = r.get("summary", "")
                desc = r.get("description", "")
                fix = r.get("fix", "")
                texts.append(f"{tid} {summary} {desc} {fix}")
                meta.append({
                    "id": tid,
                    "summary": summary,
                    "description": desc,
                    "fix": fix,
                })
            try:
                JIRA_INDEX.add(texts, meta)
                return self._send_json(200, {"ok": True, "docs": len(rows)})
            except Exception as e:
                return self._send_json(200, {"ok": False, "error": str(e)})

        # ---- Testcase training CSV ----
        if path == "/api/testcase_upload_train":
            ctype = self.headers.get("Content-Type", "")
            if "multipart/form-data" not in ctype:
                return self._send_json(400, {"ok": False, "error": "multipart_required"})
            length = int(self.headers.get("Content-Length", "0") or "0")
            raw = self.rfile.read(length)
            m = re.search(b"boundary=(.+)", ctype.encode())
            if not m:
                return self._send_json(400, {"ok": False, "error": "no_boundary"})
            boundary = b"--" + m.group(1)
            parts = raw.split(boundary)
            csv_bytes = b""
            for part in parts:
                if b"Content-Disposition" in part and b'name="file"' in part:
                    sep = b"\r\n\r\n"
                    idx = part.find(sep)
                    if idx != -1:
                        csv_bytes = part[idx+len(sep):]
                        csv_bytes = csv_bytes.rstrip(b"\r\n--")
                        break
            if not csv_bytes:
                return self._send_json(400, {"ok": False, "error": "no_file"})
            import csv as _csv
            from io import StringIO
            txt = csv_bytes.decode("utf-8", errors="ignore")
            rows = list(_csv.DictReader(StringIO(txt)))
            if not rows:
                return self._send_json(200, {"ok": False, "error": "empty_csv"})
            texts, meta = [], []
            for r in rows:
                tid = r.get("id", "")
                name = r.get("name", "")
                uvmv = r.get("uvm_version", "")
                summary = r.get("summary", "")
                desc = r.get("description", "")
                code = r.get("code", "")
                texts.append(f"{tid} {name} {uvmv} {summary} {desc} {code}")
                meta.append({
                    "id": tid,
                    "name": name,
                    "uvm_version": uvmv,
                    "summary": summary,
                    "description": desc,
                    "code": code,
                })
            try:
                TC_INDEX.add(texts, meta)
                return self._send_json(200, {"ok": True, "docs": len(rows)})
            except Exception as e:
                return self._send_json(200, {"ok": False, "error": str(e)})

        # ---- PDF upload/index ----
        if path == "/api/pdf_upload":
            ctype = self.headers.get("Content-Type", "")
            if "multipart/form-data" not in ctype:
                return self._send_json(400, {"ok": False, "error": "multipart_required"})
            length = int(self.headers.get("Content-Length", "0") or "0")
            raw = self.rfile.read(length)
            m = re.search(b"boundary=(.+)", ctype.encode())
            if not m:
                return self._send_json(400, {"ok": False, "error": "no_boundary"})
            boundary = b"--" + m.group(1)
            parts = raw.split(boundary)
            pdf_bytes = b""
            filename = "upload.pdf"
            for part in parts:
                if b"Content-Disposition" in part and b'name="file"' in part:
                    fm = re.search(b'filename="([^"]+)"', part)
                    if fm:
                        filename = fm.group(1).decode("utf-8", errors="ignore")
                    sep = b"\r\n\r\n"
                    idx = part.find(sep)
                    if idx != -1:
                        pdf_bytes = part[idx+len(sep):]
                        pdf_bytes = pdf_bytes.rstrip(b"\r\n--")
                        break
            if not pdf_bytes:
                return self._send_json(400, {"ok": False, "error": "no_file"})
            try:
                pages = _extract_pdf_text(pdf_bytes)
            except Exception as e:
                return self._send_json(200, {"ok": False, "error": str(e)})
            meta = load_pdf_meta()
            doc_id = meta.get("next_id", 1)
            chunks_text, chunks_meta = [], []
            total_chunks = 0
            for page_no, txt in pages:
                if not txt.strip():
                    continue
                for chunk in _chunk_text(txt, max_chars=800):
                    chunks_text.append(chunk)
                    chunks_meta.append({
                        "doc_id": doc_id,
                        "doc_name": filename,
                        "page": page_no,
                        "text": chunk,
                    })
                    total_chunks += 1
            if chunks_text:
                try:
                    PDF_INDEX.add(chunks_text, chunks_meta)
                except Exception as e:
                    return self._send_json(200, {"ok": False, "error": str(e)})
            meta["docs"].append({
                "id": doc_id,
                "name": filename,
                "pages": len(pages),
                "chunks": total_chunks,
                "timestamp": time.time(),
            })
            meta["next_id"] = doc_id + 1
            save_pdf_meta(meta)
            return self._send_json(200, {"ok": True, "doc_id": doc_id, "name": filename, "chunks": total_chunks})

        if path == "/api/pdf_list":
            m = load_pdf_meta()
            return self._send_json(200, {"ok": True, "docs": m.get("docs", [])})

        if path == "/api/pdf_query":
            payload = parse_json_body(self)
            q = (payload.get("q") or "").strip()
            if not q:
                return self._send_json(200, {"ok": False, "error": "empty_query"})
            try:
                PDF_INDEX._ensure_loaded()
                hits = PDF_INDEX.search(q, top_k=8) if PDF_INDEX.emb is not None else []
            except Exception as e:
                return self._send_json(200, {"ok": False, "error": str(e)})
            for h in hits:
                t = h.get("text", "")
                if len(t) > 1200:
                    h["text"] = t[:1200] + "..."
            return self._send_json(200, {"ok": True, "results": hits})

        # ---- Generic LLM chat ----
        if path == "/api/llm_chat":
            payload = parse_json_body(self)
            text_q = (payload.get("text") or "").strip()
            if not text_q:
                return self._send_json(200, {"ok": False, "error": "empty_prompt"})
            try:
                out = llm_generate(text_q)
                return self._send_json(200, {"ok": True, "text": out})
            except Exception as e:
                return self._send_json(200, {"ok": False, "error": str(e)})

        return self._send_json(404, {"ok": False, "error": "unknown_endpoint"})

def run():
    init_db()
    host = CONFIG["server"]["host"]
    port = CONFIG["server"]["port"]
    httpd = HTTPServer((host, port), XgentHandler)
    print(f"Xgent Agentic BGE app running at http://{host}:{port}")
    httpd.serve_forever()

if __name__ == "__main__":
    run()
