let currentUser = null;

function spin(on){
  document.getElementById("spinner").style.display = on ? "flex" : "none";
}

async function apiPost(path, body){
  const res = await fetch(path, {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body: JSON.stringify(body || {})
  });
  return await res.json();
}

function switchTab(name){
  document.querySelectorAll(".tab-btn").forEach(btn=>{
    btn.classList.toggle("active", btn.dataset.tab === name);
  });
  document.querySelectorAll(".tab-panel").forEach(p=>{
    p.classList.toggle("active", p.id === "tab-" + name);
  });
}

function initTabs(){
  document.querySelectorAll(".tab-btn").forEach(btn=>{
    btn.addEventListener("click", ()=>switchTab(btn.dataset.tab));
  });
}

async function handleLogin(){
  const u = document.getElementById("login-username").value.trim();
  const p = document.getElementById("login-password").value;
  const err = document.getElementById("login-error");
  err.textContent = "";
  if(!u || !p){
    err.textContent = "Enter username and password.";
    return;
  }
  spin(true);
  try{
    const r = await apiPost("/api/login",{username:u,password:p});
    if(r.ok){
      currentUser = r.username;
      document.getElementById("user-label").textContent = currentUser;
      document.getElementById("login-overlay").style.display = "none";
    }else{
      err.textContent = "Login failed: " + (r.error || "invalid credentials");
    }
  }catch(e){
    err.textContent = "Login error: " + e;
  }finally{
    spin(false);
  }
}

async function handleLogout(){
  await apiPost("/api/logout",{});
  currentUser = null;
  document.getElementById("user-label").textContent = "guest";
  document.getElementById("login-overlay").style.display = "flex";
}

function detectJiraId(text){
  const m = text && text.match(/\b[A-Z][A-Z0-9]+-\d+\b/);
  return m ? m[0] : null;
}

function decideRoute(mode, text){
  if(mode && mode !== "auto") return mode;
  const t = (text || "").toLowerCase();
  if(detectJiraId(text || "")) return "jira";
  if(t.includes("pdf") || t.includes("document") || t.includes("spec")) return "pdf";
  return "jira";
}

function setRouteLabel(route){
  const map = {
    jira:"Recipe: Jira BGE flow (similar Jira + testcases + LLM).",
    pdf:"Recipe: PDF BGE QA.",
    code:"Recipe: Generic code/answer from LLM.",
    auto:"Recipe: Auto routing."
  };
  document.getElementById("route-label").textContent = map[route] || ("Route: " + route);
}

async function handleChat(){
  const input = document.getElementById("chat-input").value.trim();
  const mode = document.getElementById("chat-mode").value;
  const out = document.getElementById("chat-output");
  if(!input){
    out.textContent = "Please enter a Jira ID or question.";
    return;
  }
  const route = decideRoute(mode, input);
  setRouteLabel(route);
  spin(true);
  try{
    if(route === "jira"){
      const jiraId = detectJiraId(input);
      const payload = jiraId ? {jira_id:jiraId} : {description_override:input};
      const r = await apiPost("/api/jira_flow", payload);
      if(!r.ok){
        out.textContent = "Jira flow error: " + (r.error || "");
      }else{
        out.textContent = JSON.stringify(r,null,2);
      }
    }else if(route === "pdf"){
      const r = await apiPost("/api/pdf_query",{q:input});
      if(!r.ok){
        out.textContent = "PDF query error: " + (r.error || "");
      }else{
        out.textContent = JSON.stringify(r,null,2);
      }
    }else{
      const r = await apiPost("/api/llm_chat",{text:input});
      if(!r.ok){
        out.textContent = "LLM error: " + (r.error || "");
      }else{
        out.textContent = r.text;
      }
    }
  }catch(e){
    out.textContent = "Error: " + e;
  }finally{
    spin(false);
  }
}

async function seedDemoJira(){
  spin(true);
  try{
    const r = await apiPost("/api/jira_seed_demo",{});
    const out = document.getElementById("chat-output");
    if(r.ok) out.textContent = "Demo Jira index seeded.";
    else out.textContent = "Seed error: " + (r.error || "");
  }catch(e){
    document.getElementById("chat-output").textContent = "Seed error: " + e;
  }finally{
    spin(false);
  }
}

async function uploadPdf(){
  const file = document.getElementById("pdf-file").files[0];
  const status = document.getElementById("pdf-status");
  if(!file){
    status.textContent = "Select a PDF file first.";
    status.className = "status-err";
    return;
  }
  const fd = new FormData();
  fd.append("file", file);
  spin(true);
  try{
    const res = await fetch("/api/pdf_upload",{method:"POST",body:fd});
    const j = await res.json();
    if(j.ok){
      status.textContent = `Indexed ${j.name} (doc_id=${j.doc_id}, chunks=${j.chunks})`;
      status.className = "status-ok";
      await loadPdfList();
    }else{
      status.textContent = "PDF error: " + (j.error || "");
      status.className = "status-err";
    }
  }catch(e){
    status.textContent = "PDF error: " + e;
    status.className = "status-err";
  }finally{
    spin(false);
  }
}

async function loadPdfList(){
  const box = document.getElementById("pdf-list");
  box.textContent = "Loading…";
  try{
    const r = await apiPost("/api/pdf_list",{});
    if(!r.ok){
      box.textContent = "Error: " + (r.error || "");
      return;
    }
    const docs = r.docs || [];
    if(docs.length === 0){
      box.textContent = "No PDFs trained yet.";
      return;
    }
    let txt = "";
    docs.forEach(d=>{
      txt += `Doc ${d.id} | ${d.name} | pages=${d.pages} | chunks=${d.chunks}\n`;
    });
    box.textContent = txt;
  }catch(e){
    box.textContent = "Error: " + e;
  }
}

async function uploadJiraCsv(){
  const file = document.getElementById("jira-file").files[0];
  const status = document.getElementById("jira-status");
  if(!file){
    status.textContent = "Select a Jira CSV first.";
    status.className = "status-err";
    return;
  }
  const fd = new FormData();
  fd.append("file", file);
  spin(true);
  try{
    const res = await fetch("/api/jira_upload_train",{method:"POST",body:fd});
    const j = await res.json();
    if(j.ok){
      status.textContent = `Trained Jira model on ${j.docs} rows.`;
      status.className = "status-ok";
    }else{
      status.textContent = "Training error: " + (j.error || "");
      status.className = "status-err";
    }
  }catch(e){
    status.textContent = "Training error: " + e;
    status.className = "status-err";
  }finally{
    spin(false);
  }
}

async function uploadTcCsv(){
  const file = document.getElementById("tc-file").files[0];
  const status = document.getElementById("tc-status");
  if(!file){
    status.textContent = "Select a testcase CSV first.";
    status.className = "status-err";
    return;
  }
  const fd = new FormData();
  fd.append("file", file);
  spin(true);
  try{
    const res = await fetch("/api/testcase_upload_train",{method:"POST",body:fd});
    const j = await res.json();
    if(j.ok){
      status.textContent = `Trained testcase model on ${j.docs} rows.`;
      status.className = "status-ok";
    }else{
      status.textContent = "Training error: " + (j.error || "");
      status.className = "status-err";
    }
  }catch(e){
    status.textContent = "Training error: " + e;
    status.className = "status-err";
  }finally{
    spin(false);
  }
}

document.addEventListener("DOMContentLoaded", ()=>{
  initTabs();
  document.getElementById("login-btn").addEventListener("click", handleLogin);
  document.getElementById("login-password").addEventListener("keydown", e=>{
    if(e.key === "Enter") handleLogin();
  });
  document.getElementById("logout-btn").addEventListener("click", handleLogout);
  document.getElementById("chat-send").addEventListener("click", handleChat);
  document.getElementById("jira-demo-seed").addEventListener("click", seedDemoJira);
  document.getElementById("pdf-upload-btn").addEventListener("click", uploadPdf);
  document.getElementById("jira-train-btn").addEventListener("click", uploadJiraCsv);
  document.getElementById("tc-train-btn").addEventListener("click", uploadTcCsv);
  loadPdfList();
});
